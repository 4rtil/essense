import * as React from 'react';
import { BoardComponent, Link } from '../components'

export const HomeTemplate = (state) => <div>
    {state.loading
        ? <h2>HomeView Loading...</h2>
        : <h2>HomeView</h2>
    }
    <BoardComponent name="Board Component" />
</div>
