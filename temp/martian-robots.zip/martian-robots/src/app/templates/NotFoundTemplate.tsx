import * as React from 'react';


export const NotFoundTemplate = () => <div>
    <h2>404</h2>
    <h3>Page not found</h3>
</div>
