export { NotFoundTemplate } from '../templates/NotFoundTemplate'
export { HomeTemplate } from '../templates/HomeTemplate'
export { AboutTemplate } from '../templates/AboutTemplate';
export { DefaultThemeTemplate } from '../templates/DefaultThemeTemplate';
