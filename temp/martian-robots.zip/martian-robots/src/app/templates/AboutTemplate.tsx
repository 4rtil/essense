import * as React from 'react';


export const AboutTemplate = (state) => <div>
    {state.loading
    ? <h2>About Loading...</h2>
    : <h2>About</h2>
    }
    <p>
        This project includes a working example of React, React Router, and TypeScript.
        It is <a href="https://github.com/toddlucas/react-tsx-starter">hosted on Github</a>.
    </p>
</div>
