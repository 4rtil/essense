import * as React from 'react';
import { IndexLink, Link } from '../components';


export const DefaultThemeTemplate = (props) => <div className="container">
    <nav className="navbar navbar-default navbar-fixed-top">
        <div className="container-fluid">
            <div className="navbar-header">
                <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span className="sr-only">Toggle navigation</span>
                    <span className="icon-bar"></span>
                    <span className="icon-bar"></span>
                    <span className="icon-bar"></span>
                </button>
                <IndexLink className="navbar-brand" to="/">Robots example</IndexLink>
            </div>
            <div id="navbar" className="navbar-collapse collapse">
                <ul className="nav navbar-nav">
                    <li className={props.location.pathname === '/' && 'active'}><IndexLink to="/">Home</IndexLink></li>
                    <li className={props.location.pathname.match('^/about') && 'active'}><Link to="/about">About</Link></li>
                    <li className={props.location.pathname.match(/^\/[^/about]\w+/) && 'active'}><Link to="/notfound">Not Found</Link></li>
                </ul>   
            </div>
        </div>
    </nav>
    
    <div className="robots">
        {props.children}
    </div>
</div>
