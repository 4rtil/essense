import * as React from 'react'
import { Store, createStore, combineReducers, compose, applyMiddleware } from 'redux'
import { routerReducer, routerMiddleware } from 'react-router-redux'
import { updateBoard } from './reducers'


const configureStore = (history, initialState?: {} ) => {
    const reducer = combineReducers({
        count: updateBoard,
        routing: routerReducer
    });

    const store = createStore(
        reducer,
        initialState,
        compose(
            applyMiddleware(
                routerMiddleware(history)
            )
        )
    );

    return store;
}

export { configureStore }
