import {
    ADD_ROBOT, REMOVE_ROBOT,
    UPDATE_BOARD_WIDTH, UPDATE_BOARD_HEIGHT,
    UPDATE_NEW_ROBOT,
    ROBOT_EXECUTE_INSTRUCTIONS
} from '../constants'
import * as _ from 'underscore'

const turnRightSequense = 'NESW';
const moveForward = (position) => {
    const moves = {
        N: (robot) => ({ y: robot.y + 1 }),
        S: (robot) => ({ y: robot.y - 1 }),
        W: (robot) => ({ x: robot.x + 1 }),
        E: (robot) => ({ x: robot.x - 1 })
    };

    return _.extend({}, position, moves[position.orientation](position));
};

const turnRight = (position) => {
    var index = turnRightSequense.indexOf(position.orientation);
    return _.defaults({
        orientation: 0 === index ? _.last(turnRightSequense) : turnRightSequense[index - 1]
    }, position);
}

const turnLeft = (position) => {
    var index = turnRightSequense.indexOf(position.orientation);
    return _.defaults({
        orientation: (turnRightSequense.length - 1) === index ? turnRightSequense[0] : turnRightSequense[index + 1]
    }, position);
}

const isLost = (state, position) => {
    if (position.x < 0 || position.x >= state.width) {
        return true;
    }
    if (position.y < 0 || position.y >= state.height) {
        return true;
    }
    return false;  
}

const initialState = {
  newRobot: {
    x: 0,
    y: 0,
    orientation: 'N',
    instructions: '',
    isLost: false,
    positions: []
  },
  width: 3,
  height: 3,
  robots: [],
  number: 0,
  report: []
}

const updateBoard = (state = initialState, action) => {
    if (action.type === ADD_ROBOT) {
        let robots = Array.prototype.slice.call(state.robots);
        robots.push(_.extend({}, action.robot, {
            id: robots.length,
            positions: [_.pick(action.robot, 'x', 'y', 'orientation')]
        }));
        return _.defaults({
            robots: robots,
            number: robots.length
        }, state);
    }
    else if (action.type === REMOVE_ROBOT) {
        let robot = _.findWhere(state.robots, { id: action.robotId });
        let robots = _.difference(state.robots, [robot]);
        return _.defaults({
            robots: robots,
            number: robots.length
        }, state);
    }
    else if (action.type === UPDATE_BOARD_WIDTH) {
        return _.defaults({
            width: action.width
        }, state);
    }
    else if (action.type === UPDATE_BOARD_HEIGHT) {
        return _.defaults({
            height: action.height
        }, state);
    }
    else if (action.type === UPDATE_NEW_ROBOT) {
        return _.defaults({
            newRobot: _.extend({}, state.newRobot, action.newRobot)
        }, state);
    }
    else if (action.type === ROBOT_EXECUTE_INSTRUCTIONS) {
        var robots = _.clone(state.robots);
        _.each(robots, (robot) => {
            if (robot.isLost) {
                return;  
          }  
            var positions = _.reduce(robot.instruction, (res, command) => {
                if (robot.isLost) {
                    return res;
                }
                let position = _.extend({
                    time: action.time
                }, _.last(res));

                switch (command) {
                    case 'F':
                        let newPosition = moveForward(position);    
                        robot.isLost = isLost(state, newPosition);
                        res.push(newPosition);
                        break;
                    case 'L':
                        res.push(turnLeft(position));
                        break;
                    case 'R':
                        res.push(turnRight(position));
                        break;
                    default:
                        throw new Error('Instruction: [' + robot.instruction + '] has unexpected command: ' + command + '.');
                }
                return res;
            }, _.clone(robot.positions));

            robot.positions = positions;
        });
        let report = _.map(robots, robot => {
            let twoPos = _.last(robot.positions, 2);
            let pos: any = _.last(twoPos);
            if (robot.isLost) {
                pos = _.first(twoPos);
            }
            return [pos.x, pos.y, pos.orientation, robot.isLost ? 'LOST' : ''].join(' ');
        });
      
        return _.defaults({
            robots: robots,
            report: report
        }, state);
    }

    return state;
}

export { updateBoard }