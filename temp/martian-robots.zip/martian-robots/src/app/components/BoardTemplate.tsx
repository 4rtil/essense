import * as React from 'react';
import * as _ from 'underscore';

const iconName = (robot) => {
    var position = _.last(robot.positions) || robot.orientation;
    if (robot.isLost) {
        return 'glyphicon-remove-circle';
    }
    switch (position.orientation) {
        case 'W':
            return 'glyphicon-circle-arrow-right';     
        case 'E':
            return 'glyphicon-circle-arrow-left';     
        case 'S':
            return 'glyphicon-circle-arrow-down';     
        case 'N':
        default:
            return 'glyphicon-circle-arrow-up';  
    }
}

export const BoardTemplate = (view, props, state) => <div>
    <div className="row form-group">
        <div className="col-md-4"> 
            <label>World right coord</label>
            <div className="input-group">
                <div className="input-group-addon"
                    onClick={() => props.updateBoardWidth(Math.max(0, props.width - 1))}
                    >
                    <span className="glyphicon glyphicon-minus"></span>
                </div>
                <input className="form-control" type="text" value={props.width}
                    onChange={(e) => view.onWidthChange(e)} />
                <div className="input-group-addon"
                    onClick={() => props.updateBoardWidth(Math.min(50, props.width + 1))}
                    >
                    <span className="glyphicon glyphicon-plus"></span>
                </div>    
            </div>
        </div>
        <div className="col-md-4"> 
            <label>World upper coord</label>
            <div className="input-group">
                <div className="input-group-addon"
                onClick={() => props.updateBoardHeight(Math.max(0, props.height - 1))}      
                    >
                    <span className="glyphicon glyphicon-minus"></span>
                </div>    
                <input className="form-control" type="text" value={props.height}
                    onChange={(e) => view.onHeightChange(e)} />
                <div className="input-group-addon"
                onClick={() => props.updateBoardHeight(Math.min(50, props.height + 1))}    
                    >
                    <span className="glyphicon glyphicon-plus"></span>
                </div>    
            </div>
        </div>
    </div>
    <div className="row">
        <div className="panel panel-default">
            <div className="panel-heading">
                Create Robot
            </div>
            <div className="panel-body"><form>
                <div className="row">        
                    <div className="col-md-6 form-group">
                        <label>Initial coordinates of the robot (x y)</label>
                        <input className="form-control" type="text" placeholder="e.g. 1 1"
                         onChange={e => view.onCoordinatesChange(e)}    
                            />
                        <p className="help-block">Please, use two integer numbers, separated by space. The maximum value for any coordinate is 50.</p>
                    </div>
                    <div className="col-md-6 form-group">
                        <label>Orientation (N, S, E, W)</label>
                        <select className="form-control"
                         onChange={e=>view.onOrientationChange(e)}    
                            >
                            <option value="N">N</option>
                            <option value="S">S</option>
                            <option value="E">E</option>
                            <option value="W">W</option>
                        </select>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12 form-group">
                        <label>Robot instruction</label>
                        <input className="form-control" type="text" placeholder="e.g. RFRFRFRF"
                         onChange={e => view.onInstructionChange(e)}    
                            />
                        <p className="help-block">A string of the letters “L”, “R”, and “F”. Less than 100 characters in length</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12 btn-group">    
                        <button type="submit" className="btn btn-danger"
                         onClick={e => view.createRobot(e)}
                         >Insert</button>
                    </div>
                </div>
            </form></div>
        </div>
    </div>
    <div className="row">
        <div className="panel panel-default">
            <div className="panel-heading">
                The surface of Mars ({props.number} - robots)
            </div>
            <div className="panel-body">
            <div className="btn-group">
                <button className="btn btn-success dropdown-toggle"
                    onClick={e => view.executeInstructions(e)}
                    >Execute Instructions</button>
            </div>
            {_.map(_.range(props.height -1, -1, -1), y =>
                <div key={y}>
                {_.map(_.range(0, props.width), x => {
                    var robot = view.findRobot(x, y);        
                    return (<span
                        key={[x, y].join('x')}
                        className={["glyphicon", robot ? iconName(robot) : "glyphicon-unchecked"].join(' ')}
                        onClick={_ => robot && props.removeRobot(robot.id)}
                        style={{fontSize: '20px'}}
                        ></span>);
                })}
                </div>
            )}
            </div>
        </div>
    </div>
        <div className="row">
        <div className="panel panel-default">
            <div className="panel-heading">
                Report
            </div>
            <div className="panel-body">
                {_.map(props.report, (line, index) => <div key={index}>{line}</div>)}
            </div>
        </div>
    </div>
</div>