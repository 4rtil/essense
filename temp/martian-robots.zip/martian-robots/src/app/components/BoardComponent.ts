﻿import * as _ from 'underscore';
import * as React from 'react';
import { BoardTemplate } from './BoardTemplate';
import { connect } from 'react-redux';
import {
    addRobot, removeRobot,
    updateBoardWidth, updateBoardHeight,
    updateNewRobot, executeInstructions
} from '../actions';

export { BoardComponent, BoardProps }

interface BoardProps {
    newRobot?: any
    name?: string
    number?: number
    width?: number
    height?: number
    robots?: any[]
    updateBoardWidth?: (width) => any
    updateBoardHeight?: (height) => any
    updateNewRobot?: (newRobot) => any
    addRobot?: (newRobot) => any
    removeRobot?: (id) => any
    executeInstructions?: () => any
}

@connect(state => _.extend({}, state.count),
  { addRobot, removeRobot, updateBoardWidth, updateBoardHeight, updateNewRobot, executeInstructions }
)
class BoardComponent extends React.Component<BoardProps, any> {

    onHeightChange(evnt) {
        evnt && evnt.preventDefault();
        this.props.updateBoardHeight(+evnt.target.value);
    }
    
    onWidthChange(evnt) {
        evnt && evnt.preventDefault();
        this.props.updateBoardWidth(+evnt.target.value);
    }

    onCoordinatesChange(evnt) {
        evnt && evnt.preventDefault();
        let coordinates = '' + evnt.target.value;
        let pair = coordinates.split(/[^\d]+/);
        let x = +pair[0];
        let y = pair.length > 1 ? +pair[1]: +pair[0];

        this.props.updateNewRobot({
            x, y
        })
    }

    onOrientationChange(evnt) {
        evnt && evnt.preventDefault();
        let orientation = evnt.target.value;

        this.props.updateNewRobot({
            orientation
        })
    }

    onInstructionChange(evnt) {
        evnt && evnt.preventDefault();
        let instruction = evnt.target.value;

        this.props.updateNewRobot({
            instruction
        });
    }

    createRobot(evnt) {
        evnt && evnt.preventDefault();

        this.props.addRobot(this.props.newRobot);
    }

    findRobot(x, y) {
        let robot = _.find(this.props.robots, robot => {
            let twoPos: any = _.last(robot.positions, 2);
            let position: any = _.last(twoPos);
            if (robot.isLost) {
                position = _.first(twoPos);
            }
            return position.x === x && position.y === y;
        });

        return robot;
    }

    executeInstructions(evnt) {
        evnt && evnt.preventDefault();

        this.props.executeInstructions();
    }
    
    render() {
        return BoardTemplate(this, this.props, this.state);
    }
}
