
import * as React from 'react';
import { Route, IndexRoute } from 'react-router';
import { DefaultThemeView, HomeView, AboutView, NotFoundView } from './views';


const routes = (
    <Route path="/" component={DefaultThemeView}>
        <IndexRoute component={HomeView}/>
        <Route path="/about" component={AboutView}/>
        <Route path="*" component={NotFoundView} />
    </Route>
);

export { routes };
