import {
  ADD_ROBOT, REMOVE_ROBOT,
  UPDATE_BOARD_WIDTH, UPDATE_BOARD_HEIGHT,
  UPDATE_NEW_ROBOT,
  ROBOT_EXECUTE_INSTRUCTIONS
} from '../constants'

export function addRobot(robot) {
  return {
    type: ADD_ROBOT,
    robot
  }
}

export function removeRobot(robotId) {
  return {
    type: REMOVE_ROBOT,
    robotId
  }
}

export function updateBoardWidth(width) {
  return {
    type: UPDATE_BOARD_WIDTH,
    width
  }
}

export function updateBoardHeight(height) {
  return {
    type: UPDATE_BOARD_HEIGHT,
    height
  }
}

export function updateNewRobot(newRobot) {
  return {
    type: UPDATE_NEW_ROBOT,
    newRobot
  }
}

export function executeInstructions() {
    return {
        type: ROBOT_EXECUTE_INSTRUCTIONS,
        time: new Date()
    }
}
