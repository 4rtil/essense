﻿
import * as React from 'react';
import { AboutTemplate } from '../templates';

export { AboutView }


class AboutView extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = { loaded: false };
    }
    
    componentDidMount() {
        this.setState({ loaded: true });
    }
    
    render() {
        return AboutTemplate(this.state);
    }
}
