﻿import * as React from 'react';
import { NotFoundTemplate } from '../templates';

export { NotFoundView }


class NotFoundView extends React.Component<any, any> {
    render() {
        return NotFoundTemplate();
    }
}
