
import * as React from 'react';
import { DefaultThemeTemplate } from '../templates';

export { DefaultThemeView }


class DefaultThemeView extends React.Component<any, any> {

    render() {
        return DefaultThemeTemplate(this.props);
    }
}
