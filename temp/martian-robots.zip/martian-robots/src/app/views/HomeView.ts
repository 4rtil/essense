﻿
import * as React from 'react';
import { HomeTemplate } from '../templates';

export { HomeView, HomeProps }

interface HomeProps {
    loaded: boolean;
}

class HomeView extends React.Component<HomeProps, any> {
    constructor(props: any) {
        super(props);
        this.state = { loaded: false };
    }
    
    componentDidMount () {
        this.setState({ loaded: true });
    }
    
    render () {
        return HomeTemplate(this.state);
    }
}
