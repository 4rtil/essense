/// <reference path="../typings/index.d.ts"/>
"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var express = require('express');
var http = require('http');
var path = require('path');
var React = require('react');
var ReactDOMServer = require('react-dom/server');
var react_router_1 = require('react-router');
var store_1 = require('./app/store');
var react_router_redux_1 = require('react-router-redux');
var react_redux_1 = require('react-redux');
//import * as history from 'history';
var routes_1 = require('./app/routes');
var app = express();
//var memoryHistory = history.createMemoryHistory();
// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'vash');
var min = '';
// development only
if ('development' == app.get('env')) {
}
app.use(express.static(path.join(__dirname, '.')));
app.get('/help', function (req, res) {
    res.render('help', { title: 'Help', min: min });
});
app.use(function (req, res, next) {
    var location = req.url;
    var memoryHistory = react_router_1.createMemoryHistory(req.originalUrl);
    var store = store_1.configureStore(memoryHistory);
    var history = react_router_redux_1.syncHistoryWithStore(memoryHistory, store);
    react_router_1.match({ history: history, routes: routes_1.routes, location: location }, function (error, redirectLocation, renderProps) {
        var html = ReactDOMServer.renderToString(React.createElement(react_redux_1.Provider, {store: store}, React.createElement(react_router_1.RouterContext, __assign({}, renderProps))));
        return res.render('main', { content: html, title: 'Home', min: min });
    });
});
http.createServer(app).listen(app.get('port'), function () {
    console.log('Express server listening on port ' + app.get('port'));
});
