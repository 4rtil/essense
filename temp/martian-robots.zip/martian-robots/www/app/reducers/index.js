"use strict";
var boardReducers_1 = require('../components/boardReducers');
exports.updateBoard = boardReducers_1.updateBoard;
