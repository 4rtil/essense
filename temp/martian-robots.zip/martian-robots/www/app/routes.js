"use strict";
var React = require('react');
var react_router_1 = require('react-router');
var views_1 = require('./views');
var routes = (React.createElement(react_router_1.Route, {path: "/", component: views_1.DefaultThemeView}, React.createElement(react_router_1.IndexRoute, {component: views_1.HomeView}), React.createElement(react_router_1.Route, {path: "/about", component: views_1.AboutView}), React.createElement(react_router_1.Route, {path: "*", component: views_1.NotFoundView})));
exports.routes = routes;
