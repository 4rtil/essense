"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var React = require('react');
var templates_1 = require('../templates');
var DefaultThemeView = (function (_super) {
    __extends(DefaultThemeView, _super);
    function DefaultThemeView() {
        _super.apply(this, arguments);
    }
    DefaultThemeView.prototype.render = function () {
        return templates_1.DefaultThemeTemplate(this.props);
    };
    return DefaultThemeView;
}(React.Component));
exports.DefaultThemeView = DefaultThemeView;
