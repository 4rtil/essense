"use strict";
var React = require('react');
var components_1 = require('../../components');
var HomeTemplate = function (state) {
    return React.createElement("div", null, state.loading
        ? React.createElement("h2", null, "HomeView Loading...")
        : React.createElement("h2", null, "HomeView"), React.createElement(components_1.Hello, {name: "world"}), React.createElement("div", null, React.createElement(components_1.Link, {to: "/about"}, "About")));
};
exports.HomeTemplate = HomeTemplate;
