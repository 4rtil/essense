"use strict";
var NotFoundTemplate_1 = require('../templates/NotFoundTemplate');
exports.NotFoundTemplate = NotFoundTemplate_1.NotFoundTemplate;
var HomeTemplate_1 = require('../templates/HomeTemplate');
exports.HomeTemplate = HomeTemplate_1.HomeTemplate;
var AppFrameTemplate_1 = require('../templates/AppFrameTemplate');
exports.AppFrameTemplate = AppFrameTemplate_1.AppFrameTemplate;
var AboutTemplate_1 = require('../templates/AboutTemplate');
exports.AboutTemplate = AboutTemplate_1.AboutTemplate;
