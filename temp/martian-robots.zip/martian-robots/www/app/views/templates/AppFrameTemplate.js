"use strict";
var React = require('react');
var AppFrameTemplate = function (children) {
    return React.createElement("div", null, React.createElement("h1", null, "App"), children);
};
exports.AppFrameTemplate = AppFrameTemplate;
