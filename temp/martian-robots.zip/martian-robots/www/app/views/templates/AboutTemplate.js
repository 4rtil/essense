"use strict";
var React = require('react');
var AboutTemplate = function (state) {
    return React.createElement("div", null, state.loading
        ? React.createElement("h2", null, "About Loading...")
        : React.createElement("h2", null, "About"), React.createElement("p", null, "This project includes a working example of React, React Router, and TypeScript." + ' ' + "It is ", React.createElement("a", {href: "https://github.com/toddlucas/react-tsx-starter"}, "hosted on Github"), "."));
};
exports.AboutTemplate = AboutTemplate;
