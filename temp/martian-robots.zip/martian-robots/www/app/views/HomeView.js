"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var React = require('react');
var templates_1 = require('../templates');
var HomeView = (function (_super) {
    __extends(HomeView, _super);
    function HomeView(props) {
        _super.call(this, props);
        this.state = { loaded: false };
    }
    HomeView.prototype.componentDidMount = function () {
        this.setState({ loaded: true });
    };
    HomeView.prototype.render = function () {
        return templates_1.HomeTemplate(this.state);
    };
    return HomeView;
}(React.Component));
exports.HomeView = HomeView;
