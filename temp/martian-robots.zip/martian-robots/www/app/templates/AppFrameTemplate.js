"use strict";
var React = require('react');
exports.AppFrameTemplate = function (children) { return React.createElement("div", null, React.createElement("h1", null, "App"), children); };
