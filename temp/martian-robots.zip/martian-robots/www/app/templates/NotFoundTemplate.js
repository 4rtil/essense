"use strict";
var React = require('react');
exports.NotFoundTemplate = function () { return React.createElement("div", null, React.createElement("h2", null, "404"), React.createElement("h3", null, "Page not found")); };
