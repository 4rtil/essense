"use strict";
var NotFoundTemplate_1 = require('../templates/NotFoundTemplate');
exports.NotFoundTemplate = NotFoundTemplate_1.NotFoundTemplate;
var HomeTemplate_1 = require('../templates/HomeTemplate');
exports.HomeTemplate = HomeTemplate_1.HomeTemplate;
var AboutTemplate_1 = require('../templates/AboutTemplate');
exports.AboutTemplate = AboutTemplate_1.AboutTemplate;
var DefaultThemeTemplate_1 = require('../templates/DefaultThemeTemplate');
exports.DefaultThemeTemplate = DefaultThemeTemplate_1.DefaultThemeTemplate;
