"use strict";
var BoardComponent_1 = require('./BoardComponent');
exports.BoardComponent = BoardComponent_1.BoardComponent;
var react_router_1 = require('react-router');
exports.Link = react_router_1.Link;
exports.IndexLink = react_router_1.IndexLink;
