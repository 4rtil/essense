"use strict";
var constants_1 = require('../constants');
var _ = require('underscore');
var turnRightSequense = 'NESW';
var moveForward = function (position) {
    var moves = {
        N: function (robot) { return ({ y: robot.y + 1 }); },
        S: function (robot) { return ({ y: robot.y - 1 }); },
        W: function (robot) { return ({ x: robot.x + 1 }); },
        E: function (robot) { return ({ x: robot.x - 1 }); }
    };
    return _.extend({}, position, moves[position.orientation](position));
};
var turnRight = function (position) {
    var index = turnRightSequense.indexOf(position.orientation);
    return _.defaults({
        orientation: 0 === index ? _.last(turnRightSequense) : turnRightSequense[index - 1]
    }, position);
};
var turnLeft = function (position) {
    var index = turnRightSequense.indexOf(position.orientation);
    return _.defaults({
        orientation: (turnRightSequense.length - 1) === index ? turnRightSequense[0] : turnRightSequense[index + 1]
    }, position);
};
var isLost = function (state, position) {
    if (position.x < 0 || position.x >= state.width) {
        return true;
    }
    if (position.y < 0 || position.y >= state.height) {
        return true;
    }
    return false;
};
var initialState = {
    newRobot: {
        x: 0,
        y: 0,
        orientation: 'N',
        instructions: '',
        isLost: false,
        positions: []
    },
    width: 3,
    height: 3,
    robots: [],
    number: 0,
    report: []
};
var updateBoard = function (state, action) {
    if (state === void 0) { state = initialState; }
    if (action.type === constants_1.ADD_ROBOT) {
        var robots_1 = Array.prototype.slice.call(state.robots);
        robots_1.push(_.extend({}, action.robot, {
            id: robots_1.length,
            positions: [_.pick(action.robot, 'x', 'y', 'orientation')]
        }));
        return _.defaults({
            robots: robots_1,
            number: robots_1.length
        }, state);
    }
    else if (action.type === constants_1.REMOVE_ROBOT) {
        var robot = _.findWhere(state.robots, { id: action.robotId });
        var robots_2 = _.difference(state.robots, [robot]);
        return _.defaults({
            robots: robots_2,
            number: robots_2.length
        }, state);
    }
    else if (action.type === constants_1.UPDATE_BOARD_WIDTH) {
        return _.defaults({
            width: action.width
        }, state);
    }
    else if (action.type === constants_1.UPDATE_BOARD_HEIGHT) {
        return _.defaults({
            height: action.height
        }, state);
    }
    else if (action.type === constants_1.UPDATE_NEW_ROBOT) {
        return _.defaults({
            newRobot: _.extend({}, state.newRobot, action.newRobot)
        }, state);
    }
    else if (action.type === constants_1.ROBOT_EXECUTE_INSTRUCTIONS) {
        var robots = _.clone(state.robots);
        _.each(robots, function (robot) {
            if (robot.isLost) {
                return;
            }
            var positions = _.reduce(robot.instruction, function (res, command) {
                if (robot.isLost) {
                    return res;
                }
                var position = _.extend({
                    time: action.time
                }, _.last(res));
                switch (command) {
                    case 'F':
                        var newPosition = moveForward(position);
                        robot.isLost = isLost(state, newPosition);
                        res.push(newPosition);
                        break;
                    case 'L':
                        res.push(turnLeft(position));
                        break;
                    case 'R':
                        res.push(turnRight(position));
                        break;
                    default:
                        throw new Error('Instruction: [' + robot.instruction + '] has unexpected command: ' + command + '.');
                }
                return res;
            }, _.clone(robot.positions));
            robot.positions = positions;
        });
        var report = _.map(robots, function (robot) {
            var twoPos = _.last(robot.positions, 2);
            var pos = _.last(twoPos);
            if (robot.isLost) {
                pos = _.first(twoPos);
            }
            return [pos.x, pos.y, pos.orientation, robot.isLost ? 'LOST' : ''].join(' ');
        });
        return _.defaults({
            robots: robots,
            report: report
        }, state);
    }
    return state;
};
exports.updateBoard = updateBoard;
