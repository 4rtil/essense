"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var _ = require('underscore');
var React = require('react');
var BoardTemplate_1 = require('./BoardTemplate');
var react_redux_1 = require('react-redux');
var actions_1 = require('../actions');
var BoardComponent = (function (_super) {
    __extends(BoardComponent, _super);
    function BoardComponent() {
        _super.apply(this, arguments);
    }
    BoardComponent.prototype.onHeightChange = function (evnt) {
        evnt && evnt.preventDefault();
        this.props.updateBoardHeight(+evnt.target.value);
    };
    BoardComponent.prototype.onWidthChange = function (evnt) {
        evnt && evnt.preventDefault();
        this.props.updateBoardWidth(+evnt.target.value);
    };
    BoardComponent.prototype.onCoordinatesChange = function (evnt) {
        evnt && evnt.preventDefault();
        var coordinates = '' + evnt.target.value;
        var pair = coordinates.split(/[^\d]+/);
        var x = +pair[0];
        var y = pair.length > 1 ? +pair[1] : +pair[0];
        this.props.updateNewRobot({
            x: x, y: y
        });
    };
    BoardComponent.prototype.onOrientationChange = function (evnt) {
        evnt && evnt.preventDefault();
        var orientation = evnt.target.value;
        this.props.updateNewRobot({
            orientation: orientation
        });
    };
    BoardComponent.prototype.onInstructionChange = function (evnt) {
        evnt && evnt.preventDefault();
        var instruction = evnt.target.value;
        this.props.updateNewRobot({
            instruction: instruction
        });
    };
    BoardComponent.prototype.createRobot = function (evnt) {
        evnt && evnt.preventDefault();
        this.props.addRobot(this.props.newRobot);
    };
    BoardComponent.prototype.findRobot = function (x, y) {
        var robot = _.find(this.props.robots, function (robot) {
            var twoPos = _.last(robot.positions, 2);
            var position = _.last(twoPos);
            if (robot.isLost) {
                position = _.first(twoPos);
            }
            return position.x === x && position.y === y;
        });
        return robot;
    };
    BoardComponent.prototype.executeInstructions = function (evnt) {
        evnt && evnt.preventDefault();
        this.props.executeInstructions();
    };
    BoardComponent.prototype.render = function () {
        return BoardTemplate_1.BoardTemplate(this, this.props, this.state);
    };
    BoardComponent = __decorate([
        react_redux_1.connect(function (state) { return _.extend({}, state.count); }, { addRobot: actions_1.addRobot, removeRobot: actions_1.removeRobot, updateBoardWidth: actions_1.updateBoardWidth, updateBoardHeight: actions_1.updateBoardHeight, updateNewRobot: actions_1.updateNewRobot, executeInstructions: actions_1.executeInstructions })
    ], BoardComponent);
    return BoardComponent;
}(React.Component));
exports.BoardComponent = BoardComponent;
