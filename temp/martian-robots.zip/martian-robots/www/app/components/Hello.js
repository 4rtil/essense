"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var React = require('react');
var HelloTemplate_1 = require('./HelloTemplate');
var HelloComponent = (function (_super) {
    __extends(HelloComponent, _super);
    function HelloComponent(props) {
        _super.call(this, props);
    }
    HelloComponent.prototype.render = function () {
        return HelloTemplate_1.HelloTemplate();
    };
    return HelloComponent;
}(React.Component));
exports.HelloComponent = HelloComponent;
