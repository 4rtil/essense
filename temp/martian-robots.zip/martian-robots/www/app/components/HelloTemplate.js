"use strict";
var _this = this;
var React = require('react');
exports.HelloTemplate = function () {
    return React.createElement("p", null, "Hello test, ", _this.props.name, "!");
};
