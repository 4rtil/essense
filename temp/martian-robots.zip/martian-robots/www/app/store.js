"use strict";
var redux_1 = require('redux');
var react_router_redux_1 = require('react-router-redux');
var reducers_1 = require('./reducers');
var configureStore = function (history, initialState) {
    var reducer = redux_1.combineReducers({
        count: reducers_1.updateBoard,
        routing: react_router_redux_1.routerReducer
    });
    var store = redux_1.createStore(reducer, initialState, redux_1.compose(redux_1.applyMiddleware(react_router_redux_1.routerMiddleware(history))));
    return store;
};
exports.configureStore = configureStore;
