"use strict";
var constants_1 = require('../constants');
function addRobot(robot) {
    return {
        type: constants_1.ADD_ROBOT,
        robot: robot
    };
}
exports.addRobot = addRobot;
function removeRobot(robotId) {
    return {
        type: constants_1.REMOVE_ROBOT,
        robotId: robotId
    };
}
exports.removeRobot = removeRobot;
function updateBoardWidth(width) {
    return {
        type: constants_1.UPDATE_BOARD_WIDTH,
        width: width
    };
}
exports.updateBoardWidth = updateBoardWidth;
function updateBoardHeight(height) {
    return {
        type: constants_1.UPDATE_BOARD_HEIGHT,
        height: height
    };
}
exports.updateBoardHeight = updateBoardHeight;
function updateNewRobot(newRobot) {
    return {
        type: constants_1.UPDATE_NEW_ROBOT,
        newRobot: newRobot
    };
}
exports.updateNewRobot = updateNewRobot;
function executeInstructions() {
    return {
        type: constants_1.ROBOT_EXECUTE_INSTRUCTIONS,
        time: new Date()
    };
}
exports.executeInstructions = executeInstructions;
